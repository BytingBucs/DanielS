var poker = {},
	containsNTimes;

containsNTimes = function (array, string, number) {
	var nTimes = false;
	var count = 0;
	array.forEach( function (value) {
		if (value === string) {
			count = count + 1;
		}
	});
	if (count === number) {
		nTimes = true;
	}
	return nTimes;
};

poker.containsPair = function (hand) {
	var result = false,
		handRanks;

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	ranks.forEach(function (rank) {
		if (containsNTimes(handRanks, rank, 2)) {
			result = true;
		}
	});
	
	console.log(result);
	
	return result;
};

poker.containsTwoPair = function (hand, rank1, rank2) {
	var result = false,
		handRanks;

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	ranks.forEach(function (rank) {
		if (containsNTimes(handRanks, rank1, 2) &&
			containsNTimes(handRanks, rank2, 2)) {
			result = true;
		}
	});

	return result;
};

poker.containsThreeOfAKind = function (hand) {
	var result = false,
		handRanks;

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	ranks.forEach(function (rank) {
		if (containsNTimes(handRanks, rank, 3)) {
			result = true;
		}
	});

	return result;
};

poker.containsStraight = function (hand) {
	var result = false,
		largest = 0,
		smallest = 12,
		indexNum,
		handRanks;

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	ranks.forEach(function (rank) {
		handRanks.forEach(function (card) {
			if (card === rank) {
				indexNum = ranks.indexOf(rank);
			}
			if (indexNum > largest) {
				largest = indexNum;
			}
		});
	});

	ranks.forEach(function (rank) {
		handRanks.forEach(function (card) {
			if (card === rank) {
				indexNum = ranks.indexOf(rank);
			}
			if (indexNum < smallest) {
				smallest = indexNum;
			}
		});
	});

	if ((largest - smallest) === 4 && 
		!(containsPair(hand)) && !(containsThreeOfAKind(hand)) &&
		!(containsFourOfAKind(hand))) {
		result = true;
	}

	return result;
};

poker.containsFlush = function (hand) {
	var result = false,
		handSuits;

	handSuits = hand.map(function (card) {
		return card.suit;
	});

	suits.forEach(function (suit) {
		if (containsNTimes(handSuits, suit, 5)) {
			result = true;
		}
	});

	return result;
};

poker.containsFullHouse = function (hand, rank1, rank2) {
	var result = false,
		handRanks;

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	ranks.forEach(function (rank) {
		if (containsNTimes(handRanks, rank1, 2) &&
			containsNTimes(handRanks, rank2, 3)) {
			result = true;
		}
	});

	return result;
};

poker.containsFourOfAKind = function (hand) {
	var result = false,
		handRanks;

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	ranks.forEach(function (rank) {
		if (containsNTimes(handRanks, rank, 4)) {
			result = true;
		}
	});

	return result;
};

poker.containsStraightFlush = function (hand) {
	var result = false,
		straight = containsStraight(hand),
		flush = containsFlush(hand);

	if (straight === true && flush === true) {
		result = true;
	}

	return result;
};

poker.containsRoyalFlush = function (hand) {
	var result = false,
		flush = containsFlush(hand),
		handRanks,

	handRanks = hand.map(function (card) {
		return card.rank;
	});

	if (handRanks.includes("ten") && handRanks.includes("jack") &&
		handRanks.includes("queen") && handRanks.includes("king") &&
		handRanks.includes("ace") && flush === true) {
		result = true;
	}

	return result;
};

poker.isValid = function (hand) {
	cardCount = 0,
		isValid;
	hand.forEach(function() {
		cardCount += 1;
	});
	if (cardCount === 5) {
		isValid = true;
	} else {
		isValid = false;
	}
};

poker.getHand = function (hand) {
	poker.push("hand.json");
};

module.exports = poker;