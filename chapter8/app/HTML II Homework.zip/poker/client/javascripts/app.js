var main = function(hand) {
	var ranks = ["two","three","four","five","six","seven","eight","nine",
		"ten","jack","queen","king","ace"],
		suits = ["clubs","diamonds","hearts","spades"],
		result = {};
		
		console.log(hand);
		
	if (poker.containsRoyalFlush(hand) === true) {
		result = {
			"handString":"Royal Flush",
			"error":null
		};
	} else if (poker.containsStraightFlush(hand) === true) {
		result = {
			"handString":"Straight Flush",
			"error":null
		};
	} else if (poker.containsFourOfAKind(hand) === true) {
		result = {
			"handString":"Four of a Kind",
			"error": null
		};
	} else if (poker.containsFullHouse(hand, 8, 2) === true) {
		result = {
			"handString":"Full House",
			"error":null
		};
	} else if (poker.containsFlush(hand) === true) {
		result = {
			"handString":"Flush",
			"error":null
		};
	} else if (poker.containsStraight(hand) === true) {
		result = {
			"handString":"Straight",
			"error":null
		};
	} else if (poker.containsThreeOfAKind(hand) === true) {
		result = {
			"handString":"Three of a Kind",
			"error":null
		};
	} else if (poker.containsTwoPair(hand, 8, 2) === true) {
		result = {
			"handString":"Two Pair",
			"error":null
		};
	} else if (poker.containsPair(hand) === true) {
		result = {
			"handString":"Pair",
			"error":null
		};
	} else if (poker.isValid(hand) === true) {
		result = {
			"handString":"bust",
			"error":null
		};
	} else {
		result = {
			"handString":null,
			"error":"That's an invalid poker hand!"
		};
	}
	
	console.log(result);
	
	$.post("result", result, function () {
		return result;
	});
};

$(document).ready(function() {
	$.getJSON("hand.json", function (hand) {
		main(hand);
	});
});