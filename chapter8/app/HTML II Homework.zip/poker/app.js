var poker = require("./poker.js"),
	http = require("http"),
	express = require("express"),
	bodyParser = require("body-parser"),
	app = express();
	hand = [
		{ "rank":"two", "suit":"spades" },
		{ "rank":"four", "suit":"hearts" },
		{ "rank":"two", "suit":"clubs" },
		{ "rank":"king", "suit":"spades" },
		{ "rank":"eight", "suit":"diamonds" }
	];

app.use(express.static(__dirname + "/client"));

app.use(bodyParser.urlencoded({ extended: true }));

http.createServer(app).listen(3000);

app.get("/hand.json", function (req, res) {
	res.json(hand);
});

app.post("/hand", function (req, res) {
	var result = poker.getHand(req.body.hand);
	res.json(result);
	console.log(result);
});